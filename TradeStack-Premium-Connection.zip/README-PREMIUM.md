# TradeStack Premium connection — prepared, not deployed

Uses existing Play subscription `tradestack_premium`, base plan `monthly`, package `com.jesseperez.tradestack`. No new subscription or AAB is included.

## Upload
Upload the CONTENTS of this folder to the existing Tradestack- repository, preserving paths:
- Replace index.html.
- Add tradestack-billing.js beside index.html.
- Add api/tradestack-billing.mjs inside api.
Do not delete existing files. Do not upload only the ZIP or place the files in another enclosing folder. GitHub Pages serves the frontend; the Vercel project must deploy this same updated commit for the API.

GitHub write access was rejected in this session, so no remote files were changed.

## Configure Vercel before testing
In the existing tradestack project, configure Production environment variables:
- GOOGLE_SERVICE_ACCOUNT_JSON: the complete Google service-account JSON, stored only as a secret environment variable. Never commit or paste credentials into index.html.
- TRADESTACK_BILLING_ENABLED: true when ready for internal testing. Omit or set false to disable new checkout.

The service account needs Google Play Developer API access to this app and permissions to view subscription purchases and acknowledge them. Enable the Android Publisher API in its Google Cloud project. The existing subscription must expose the monthly plan to the billing adapter in the installed build. If Play does not return the product and monthly price, investigate plan compatibility instead of creating a duplicate product.

Redeploy after configuration. GET https://tradestack-bice.vercel.app/api/tradestack-billing should return ready:true only after credentials can read the active monthly plan. This verifies catalog access, not the entire purchase flow.

## Test before launch
Use a Play license tester and the internally distributed Play-installed app, not an ordinary browser tab. Confirm Google shows a TEST payment method before completing purchase.
1. Premium displays the actual localized monthly price from Play.
2. Subscribe opens Google's confirmation; cancellation leaves access locked.
3. A successful test purchase is verified and acknowledged, then Field Assist Premium extras unlock.
4. Restart the app: restore recovers the subscription automatically. Also test the Restore purchases button.
5. Test expired/pending/on-hold subscriptions and verify extras remain locked; canceled but unexpired subscriptions retain access.
6. Confirm Free still shows likely cause and basic repair direction.

## Scope and limits
This patch connects purchase and restore to the existing Field Assist workflows, verification and equipment history. It does not redesign the other premium trade library or implement the separately planned customer-funded cloud AI service. The existing AI endpoint and its authorization/billing behavior are unchanged: do not advertise AI access as verified by this patch. Review subscription benefits before launch.

The existing content is shipped as static frontend code. Frontend access checks control the interface, not confidentiality of downloaded guides. Any paid server API must independently verify entitlement. Field Assist checks live Play entitlement at launch/foreground and every four minutes while visible; it allows a maximum five-minute verification window, so Premium extras require periodic connectivity. Core free content remains unchanged. There is no account database or real-time Google notification handler in this patch.

Billing support was found in the AAB, but real device purchase compatibility, Play signing/domain association, acknowledgment permissions and deployment remain untested. No real charge was made.

## Validation
Run node verify.mjs from this folder. Tests cover subscription states, product/plan/expiry rejection, origin rejection, disabled configuration, restore/revocation, checkout success/cancel/pending, and JavaScript syntax using mocked Google responses. A passing mock test is not a live purchase test.

## References
https://chromeos.dev/en/publish/pwa-play-billing
https://developers.google.com/android-publisher/api-ref/rest/v3/purchases.subscriptionsv2/get
https://developers.google.com/android-publisher/api-ref/rest/v3/purchases.subscriptions/acknowledge
