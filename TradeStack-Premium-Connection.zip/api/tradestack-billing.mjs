import { createSign, createPrivateKey } from 'node:crypto';
const PACKAGE = 'com.jesseperez.tradestack';
const PRODUCT = 'tradestack_premium';
const PLAN = 'monthly';
const ROOT = 'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/';
const origins = new Set(['https://jesseperez00181978-tech.github.io', 'https://tradestack-bice.vercel.app']);
let cached;
function credentials() {
  const sa = JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_JSON || '{}');
  if (!sa.client_email || !sa.private_key) throw Error('configuration');
  createPrivateKey(sa.private_key);
  return sa;
}
async function accessToken() {
  if (cached && cached.until > Date.now()) return cached.token;
  const sa = credentials(), now = Math.floor(Date.now()/1000);
  const encode = x => Buffer.from(JSON.stringify(x)).toString('base64url');
  const data = encode({alg:'RS256',typ:'JWT'}) + '.' + encode({iss:sa.client_email,scope:'https://www.googleapis.com/auth/androidpublisher',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600});
  const signature = createSign('RSA-SHA256').update(data).sign(sa.private_key,'base64url');
  const r = await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion:data+'.'+signature}),signal:AbortSignal.timeout(10000)});
  const j = await r.json();
  if (!r.ok || !j.access_token) throw Error('authorization');
  cached = {token:j.access_token,until:Date.now()+Math.max(0,Math.min(Number(j.expires_in)||3600,3600)-120)*1000};
  return cached.token;
}
async function play(path, method='GET') {
  return fetch(ROOT+PACKAGE+'/'+path,{method,headers:{Authorization:'Bearer '+await accessToken(),'Content-Type':'application/json'},...(method==='POST'?{body:'{}'}:{}),signal:AbortSignal.timeout(10000)});
}
export function entitlement(purchase, now=Date.now()) {
  const states=['SUBSCRIPTION_STATE_ACTIVE','SUBSCRIPTION_STATE_IN_GRACE_PERIOD','SUBSCRIPTION_STATE_CANCELED'];
  const item=purchase.lineItems?.find(x=>x.productId===PRODUCT && x.offerDetails?.basePlanId===PLAN && Date.parse(x.expiryTime)>now);
  return {active:states.includes(purchase.subscriptionState)&&!!item,expiresAt:item?Date.parse(item.expiryTime):0};
}
export default async function handler(req,res) {
  res.setHeader('Cache-Control','no-store');
  res.setHeader('Vary','Origin');
  const origin=req.headers.origin;
  if(origin && !origins.has(origin)) return res.status(403).json({error:'Origin not allowed.'});
  if(origin) res.setHeader('Access-Control-Allow-Origin',origin);
  res.setHeader('Access-Control-Allow-Headers','Content-Type');
  res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
  if(req.method==='OPTIONS') return res.status(204).end();
  if(!['GET','POST'].includes(req.method)) return res.status(405).json({error:'Method not allowed.'});
  try {
    if(process.env.TRADESTACK_BILLING_ENABLED!=='true') return res.status(503).json({ready:false,error:'Subscriptions are being set up. Please try again later.'});
    credentials();
    if(req.method==='GET') {
      const r=await play('subscriptions/'+PRODUCT);
      if(!r.ok) throw Error('catalog');
      const j=await r.json();
      const ready=j.basePlans?.some(p=>p.basePlanId===PLAN && p.state==='ACTIVE');
      return res.status(ready?200:503).json({ready:!!ready,productId:PRODUCT,basePlanId:PLAN});
    }
    let body=req.body;
    if(typeof body==='string') {try{body=JSON.parse(body)}catch{return res.status(400).json({error:'Invalid JSON.'})}}
    const token=body?.purchaseToken;
    if(typeof token!=='string'||!token.trim()||token.length>4096) return res.status(400).json({error:'A purchase token is required.'});
    const path='purchases/subscriptionsv2/tokens/'+encodeURIComponent(token);
    const r=await play(path);
    if([400,404,410].includes(r.status)) return res.status(200).json({active:false,expiresAt:0});
    if(!r.ok) throw Error('verification');
    const j=await r.json(), result=entitlement(j);
    if(result.active && j.acknowledgementState==='ACKNOWLEDGEMENT_STATE_PENDING') {
      const ack=await play('purchases/subscriptions/'+PRODUCT+'/tokens/'+encodeURIComponent(token)+':acknowledge','POST');
      if(!ack.ok) {
        const check=await play(path);
        if(!check.ok || (await check.json()).acknowledgementState!=='ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED') throw Error('acknowledgment');
      }
    }
    return res.status(200).json({...result,productId:PRODUCT,basePlanId:PLAN});
  } catch {
    // Never log purchase tokens, service credentials, or upstream response bodies.
    return res.status(503).json({ready:false,error:'Purchase verification is temporarily unavailable. If you already paid, use Restore purchases. Do not purchase again.'});
  }
}
