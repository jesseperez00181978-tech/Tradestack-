import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import handler,{entitlement} from './api/tradestack-billing.mjs';
const now=Date.now(), line={productId:'tradestack_premium',offerDetails:{basePlanId:'monthly'},expiryTime:new Date(now+60000).toISOString()};
for(const state of ['ACTIVE','IN_GRACE_PERIOD','CANCELED']) assert.equal(entitlement({subscriptionState:'SUBSCRIPTION_STATE_'+state,lineItems:[line]},now).active,true);
for(const state of ['PENDING','ON_HOLD','PAUSED','EXPIRED','PENDING_PURCHASE_CANCELED']) assert.equal(entitlement({subscriptionState:'SUBSCRIPTION_STATE_'+state,lineItems:[line]},now).active,false);
for(const bad of [{...line,productId:'wrong'},{...line,offerDetails:{basePlanId:'yearly'}},{...line,expiryTime:new Date(now-1).toISOString()}]) assert.equal(entitlement({subscriptionState:'SUBSCRIPTION_STATE_ACTIVE',lineItems:[bad]},now).active,false);
function res(){return {setHeader(){},status(n){this.code=n;return this},json(j){this.body=j;return this},end(){return this}}}
let r=res();await handler({method:'POST',headers:{origin:'https://evil.example'},body:{}},r);assert.equal(r.code,403);
r=res();await handler({method:'GET',headers:{}},r);assert.equal(r.code,503);assert.equal(r.body.ready,false);
const html=fs.readFileSync(new URL('./index.html',import.meta.url),'utf8');
for(const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) if(m[2].trim()&&!m[1].includes('application/json'))new vm.Script(m[2]);
const js=fs.readFileSync(new URL('./tradestack-billing.js',import.meta.url),'utf8');new vm.Script(js);
let verification={active:true,productId:'tradestack_premium',expiresAt:now+60000};let purchases=[{itemId:'tradestack_premium',purchaseToken:'test-token'}];
const ctx={window:{getDigitalGoodsService:async()=>({listPurchases:async()=>purchases}),PaymentRequest:function(){},dispatchEvent(){}},document:{addEventListener(){}},setInterval(){},CustomEvent:function(){},AbortSignal,Date,fetch:async()=>({ok:true,json:async()=>verification})};vm.createContext(ctx);vm.runInContext(js,ctx);await ctx.window.TradeStackPremium.restore();assert.equal(ctx.window.TradeStackPremium.active(),true);verification={active:false};await ctx.window.TradeStackPremium.restore();assert.equal(ctx.window.TradeStackPremium.active(),false);purchases=[];assert.equal(await ctx.window.TradeStackPremium.restore(),false);
console.log('PASS: valid, canceled-unexpired, grace-period, pending, held, paused, expired, wrong product/plan, CORS, disabled checkout, restore and removal of entitlement; JS syntax.');
async function checkoutTest(mode){
 const nodes={};const root={innerHTML:'',querySelector:id=>nodes[id]??=( {textContent:'',disabled:false})};let calls=0,completion;
 const c={window:{getDigitalGoodsService:async()=>({listPurchases:async()=>[],getDetails:async()=>[{itemId:'tradestack_premium',subscriptionPeriod:'P1M',price:{currency:'USD',value:'4.99'}}]}),PaymentRequest:function(methods){assert.equal(methods[0].data.sku,'tradestack_premium');this.show=async()=>{calls++;if(mode==='cancel')throw Object.assign(Error(),{name:'AbortError'});return {details:{purchaseToken:'test'},complete:async x=>{completion=x}}}},dispatchEvent(){}},document:{addEventListener(){}},setInterval(){},CustomEvent:function(){},AbortSignal,Date,Intl,navigator:{language:'en-US'},fetch:async(url,opts)=>({ok:mode!=='unconfigured',json:async()=>opts.method==='GET'?{ready:true,productId:'tradestack_premium'}:{active:mode==='success',productId:'tradestack_premium',expiresAt:Date.now()+60000}})};
 c.PaymentRequest=c.window.PaymentRequest;vm.createContext(c);vm.runInContext(js,c);c.window.TradeStackPremium.mount(root);await new Promise(r=>setTimeout(r,0));
 if(mode==='unconfigured'){assert.equal(nodes['#tsSubscribe'].disabled,true);assert.equal(calls,0);return;}
 assert.equal(nodes['#tsSubscribe'].disabled,false);await nodes['#tsSubscribe'].onclick();assert.equal(calls,1);assert.equal(c.window.TradeStackPremium.active(),mode==='success');if(mode==='success')assert.equal(completion,'success');if(mode==='pending')assert.equal(completion,'unknown');if(mode==='cancel')assert.equal(nodes['#tsBillingStatus'].textContent,'Purchase canceled.');
}
for(const mode of ['success','cancel','pending','unconfigured'])await checkoutTest(mode);
console.log('PASS: checkout success, cancellation, pending verification and unconfigured backend prevents payment.');
